package com.atguigu.gulimall.product.vo;

import lombok.Data;

@Data
public class AttrValueWithSkuIdVo {

    private String attrValue;
    private String skuIds;
}
