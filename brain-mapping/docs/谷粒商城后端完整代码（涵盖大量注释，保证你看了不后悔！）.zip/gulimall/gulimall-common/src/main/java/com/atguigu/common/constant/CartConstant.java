package com.atguigu.common.constant;

public class CartConstant {

    public static final String TEMP_USER_COOKIE_NAME = "user-key"; //系统的用户身份信息

    public static final int TEMP_USER_COOKIE_TIMEOUT = 60*60*24*30; //60一分钟乘以60一个小时，再乘以24小时一整天，再乘以30一个月，
}
