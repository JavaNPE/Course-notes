package com.atguigu.gulimall.member.vo;

import lombok.Data;

@Data
public class MemberLoginVo {

    private String loginacct;
    private String password;
}
