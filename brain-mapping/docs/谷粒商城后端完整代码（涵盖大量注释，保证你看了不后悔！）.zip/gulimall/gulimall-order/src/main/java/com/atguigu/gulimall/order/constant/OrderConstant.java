package com.atguigu.gulimall.order.constant;

public class OrderConstant {
    //后端用户订单令牌
    public static final String USER_ORDER_TOKEN_PREFIX = "order:token:";
}
