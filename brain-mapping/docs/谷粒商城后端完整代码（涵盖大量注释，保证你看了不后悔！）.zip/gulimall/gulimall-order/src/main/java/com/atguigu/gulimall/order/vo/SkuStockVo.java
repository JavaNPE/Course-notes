package com.atguigu.gulimall.order.vo;

import lombok.Data;

@Data
public class SkuStockVo {

    private Long skuId;
    private Boolean hasStock;
}
